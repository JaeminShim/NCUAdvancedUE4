var http = require('http');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json());

var key = {
	name : 'DarkWarrior'
};

var characterJsonData = {
		name : "DarkWarrior",
		level : 1,
		itemData : [
			{
				id : 0,
				itemName : "lightsaber",
				damage : 60
			},
			{
				id : 1,
				itemName : "short sword",
				damage : 30
			},
			{
				id : 2,
				itemName : "long sword",
				damage : 40
			},
			{
				id : 3,
				itemName : "biking sword",
				damage : 45
			},
			{
				id : 4,
				itemName : "steel sword",
				damage : 55
			},
			{
				id : 5,
				itemName : "dark steel sword",
				damage : 65
			},
		]
	}

// response get-request.
app.get('/', function(req, res){

	var getData = JSON.stringify(key);
	console.log('GET-Response, Data from Client: ' + getData);

	res.send(JSON.stringify(key));

});

// response post-request.
app.post('/', function(req, res){

	var reqParam = req.body.name;
	console.log('POST-Response, Data from Client: ' + reqParam);

	if (reqParam === key.name) {

		var data = JSON.stringify(characterJsonData);
		res.send(data);
	}
});

var server = http.createServer(app);
server.listen(8000);
console.log('Server Running');